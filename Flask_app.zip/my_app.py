import re
import string
import pickle
from flask import Flask, render_template, request
import nltk
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer

nltk.download('stopwords')
nltk.download('punkt')

app = Flask(__name__)

# 전처리 함수 정의
def clean_text(text):
    text = str(text).lower()
    text = re.sub('\[.*?\]', '', text)
    text = re.sub('https?://\S+|www\.\S+', '', text)
    text = re.sub('<.*?>+', '', text)
    text = re.sub('[%s]' % re.escape(string.punctuation), '', text)
    text = re.sub('\n', '', text)
    text = re.sub('\w*\d\w*', '', text)
    return text

stop_words = stopwords.words('english')
more_stopwords = ['u', 'im', 'c', 'r', 'v', 'b', 'iû÷m', 'å£']
stop_words = stop_words + more_stopwords

def remove_stopwords(text):
    text = ' '.join(word for word in text.split(' ') if word not in stop_words)
    return text

stemmer = PorterStemmer()

def stem_text(text):
    text = ' '.join(stemmer.stem(word) for word in text.split(' '))
    return text

def preprocess_text(text):
    text = clean_text(text)
    text = remove_stopwords(text)
    text = stem_text(text)
    return text

# CountVectorizer 및 TfidfTransformer 불러오기
with open('count_vectorizer.pkl', 'rb') as cv_file:
    loaded_vect = pickle.load(cv_file)

# 모델 불러오기
with open('logistic_regression_model.pkl', 'rb') as model_file:
    model = pickle.load(model_file)

def classify_text(text):
    # 텍스트 전처리
    processed_text = preprocess_text(text)
    
    # 벡터화 및 TF-IDF 변환
    text_counts = loaded_vect.transform([processed_text])

    # 모델에 전달하여 분류
    predicted_label = model.predict(text_counts)
    return predicted_label[0]

@app.route('/')
@app.route('/home')
def home():
    return render_template('home.html')
    
@app.route('/text')
def input_page():
    return render_template('text.html')

@app.route('/result', methods=['POST'])
def result():
    user_text = request.form['user_text']
    result = classify_text(user_text)
    label = 'spam' if result == 1 else 'ham'
    if label == 'spam':
        return render_template('spam.html', user_text=user_text)
    else:
        return render_template('ham.html', user_text=user_text)
if __name__ == '__main__':
    app.run(debug=True)